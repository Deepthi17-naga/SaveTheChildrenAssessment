package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AssignmentStepDefinition {

	WebDriver driver;

	@Given("^user is already on Home Page$")
	public void user_already_on_login_page() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.savethechildren.net/");
	}

	@When("^navigate to UK site$")
	public void title_of_login_page_is_free_CRM() {
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals("Save the Children International", title);
		driver.findElement(By.id("stc-popup-continue")).click();
	}

	@Then("^user enters \"(.*)\" in the search box$")
	public void user_enters_username_and_password(String keyword) {
		driver.findElement(By.id("header__search")).sendKeys(keyword);
	}

	@Then("^user clicks on link$")
	public void user_clicks_on_login_button() {
		WebElement frameElement = driver.findElement(By.id("master-1"));
		driver.switchTo().frame(frameElement);
		WebElement link = driver
				.findElement(By.xpath("//a[contains(@class,'gs-title') and contains(text(),'Save a Life:')]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", link);
	}

	@Then("^validate page url$")
	public void user_is_on_hopme_page() {
		String title = driver.getTitle();
		System.out.println("Donate Page title ::" + title);
		Assert.assertEquals("Donate Now to Help the World's Most Vulnerable Children - Save the Children", title);
	}


}
